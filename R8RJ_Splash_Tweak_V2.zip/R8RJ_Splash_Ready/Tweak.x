#import <UIKit/UIKit.h>

@interface R8RJSplashViewController : UIViewController
@end

@implementation R8RJSplashViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = self.view.bounds;
    gradient.colors = @[
        (id)[UIColor colorWithRed:0.38 green:0.18 blue:0.62 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.12 green:0.04 blue:0.22 alpha:1.0].CGColor
    ];
    [self.view.layer insertSublayer:gradient atIndex:0];
    
    UIImageView *logoView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 130, 130)];
    logoView.center = CGPointMake(self.view.bounds.size.width / 2, 190);
    logoView.layer.cornerRadius = 65;
    logoView.clipsToBounds = YES;
    logoView.image = [UIImage imageNamed:@"logo.png"] ?: [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:@"https://apple.com/favicon.ico"]]];
    [self.view addSubview:logoView];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 280, self.view.bounds.size.width - 40, 40)];
    titleLabel.text = @" IPA DEV R8RJ ";
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont boldSystemFontOfSize:25];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];
    
    UILabel *subTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 320, self.view.bounds.size.width - 40, 30)];
    subTitleLabel.text = @"القناة الرسمية للتطبيقات @R8RIJ";
    subTitleLabel.textColor = [UIColor lightGrayColor];
    subTitleLabel.font = [UIFont systemFontOfSize:16];
    subTitleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:subTitleLabel];
    
    NSArray *titles = @[@"القناة Channel", @"الجروب Group", @"المطور R8RJ", @"دخول ~ Entry"];
    for (int i = 0; i < titles.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(45, 390 + (i * 65), self.view.bounds.size.width - 90, 52);
        [btn setTitle:titles[i] forState:UIControlStateNormal];
        btn.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.15];
        btn.layer.cornerRadius = 14;
        btn.tag = i;
        [btn addTarget:self action:@selector(tap:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
    }
}
- (void)tap:(UIButton *)sender {
    NSURL *url = nil;
    if (sender.tag == 0) url = [NSURL URLWithString:@"https://t.me/R8RIJ"];
    if (sender.tag == 1) url = [NSURL URLWithString:@"https://t.me/R8RIJ"];
    if (sender.tag == 2) url = [NSURL URLWithString:@"https://instagram.com/r8rj"];
    if (sender.tag == 3) { [self dismissViewControllerAnimated:YES completion:nil]; return; }
    if (url) [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
}
@end

%hook UIApplication
- (void)setDelegate:(id)delegate {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UIWindow *win = [UIApplication sharedApplication].keyWindow;
        if (win && win.rootViewController) {
            R8RJSplashViewController *vc = [[R8RJSplashViewController alloc] init];
            vc.modalPresentationStyle = UIModalPresentationFullScreen;
            [win.rootViewController presentViewController:vc animated:YES completion:nil];
        }
    });
}
%end
